<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Moja Prosta Strona</title>
</head>
<body>
    <p>Witaj świecie! html</p>
	<br>
	<?php echo "Witaj świecie! echo"; ?>

</body>
</html>
