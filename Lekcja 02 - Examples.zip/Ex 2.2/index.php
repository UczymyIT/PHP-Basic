<!-- Ex. 2.2 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Moja Prosta Strona</title>
</head>
<body>

	<?php
	$x = "Hello world!";
	$y = 'Hello world!';

	echo $x;
	echo "<br>";
	echo $y;
	?>

</body>
</html>
