<!-- Ex. 2.1 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Moja Prosta Strona</title>
</head>
<body>

	<?php 
	$mojText = "Ala ma kota";
	$liczba = 1; 

	echo $mojText.$liczba;
	?>

</body>
</html>
