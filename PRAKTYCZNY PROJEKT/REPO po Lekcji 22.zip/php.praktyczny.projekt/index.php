<?php
	session_start();
	include("index_functions.php");
	include("db-connect.php");
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		if(isset($_POST["login"]) && isset($_POST["password"])){
			$info = user_authentication($conn, $_POST["login"], $_POST["password"]);
		}
	}
?>
<!DOCTYPE html>
<html lang="pl">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<title>PHP praktyczny projekt</title>
	
	<meta name="description" content="Opis strony dla wyszukiwarek">
	<meta name="keywords" content="słowa kluczowe">
	<meta name="author" content="informacja o autorze">
	
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link href="style.css" rel="stylesheet" >
	
</head>
	<body>
	
	<!-- nagłówek -->
	<?php include("header.php"); 
	
	// jeśli user zalogowany
	if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"]==true){
		if(isset($info)){
			//show_text_in_paragraph($info);
			button_show($info, "success");
		}
		$text = "Zalogowany jako: ".$_SESSION["username"];
		show_text_in_paragraph($text);
		//member_show();
		include("index_member.php");
	}
	// user NIE zalogowany
	else {
		if(isset($_POST["button_pressed"]) && $_POST["button_pressed"]=="btn_login") {
			form_login_show();
		}
		else {
			if(isset($info)){
				//show_text_in_paragraph($info);
				button_show($info, "danger`");
			}
			nomember_show();
		}
	}
	
	
	include("db-disconnect.php");
	?>
    
	</body>
</html>