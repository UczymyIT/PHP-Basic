<?php

function nomember_show() {
	?>
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<p>Treść dla użytkownika nie zalogowanego.</p>
			</div>
		</div>
	</div>
	<?php
}

function member_show() {
	?>
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<p>Treść dla użytkownika zalogowanego.</p>
			</div>
		</div>
	</div>
	<?php
}

function form_login_show() {
    ?>
	<div class="container">
	<div class="row">
		<div class="col-md-4">
		</div>
		<div class="col-md-4">
			<h2 class="text-center mb-4">Logowanie</h2>
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
				<div class="form-group">
					<label for="login">Nazwa użytkownika:</label>
					<input type="text" class="form-control" name="login" id="login" placeholder="Wprowadź nazwę użytkownika">
				</div>
				<div class="form-group">
					<label for="password">Hasło:</label>
					<input type="password" class="form-control" name="password" id="password" placeholder="Wprowadź hasło">
				</div>
				<button type="submit" class="btn btn-primary" style="margin-top:10px;">Wyślij</button>
			</form>
			<?php echo '<a href="index.php"><input type="button" value="Wróć" class="btn btn-primary"  style="margin-top:10px;"></a>'; ?>
		</div>
		<div class="col-md-4">
		</div>
	</div>
	</div>
	<?php
}

function user_authentication($conn, $login, $password) {
    
    // Zapytanie SQL
    $sql = "SELECT * FROM users WHERE name = '$login' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        if ($password == $row["password"]) {
            $_SESSION["username"] = $login;
			$_SESSION["loggedin"] = true;
			return "Autentykacja udana"; 
        } else {
            return "Nieprawidłowe hasło";
        }
    } else {
        return "Użytkownik nie znaleziony";
    }
}

function show_text_in_paragraph($text) {
	?><div class="container">
		<div class="row">
			<div class="col-lg-12">
				<?php echo $text; ?>
			</div>
		</div>
	</div><?php
}

function button_show($text, $type) {
	$klasa = '';
	switch ($type) {
		case "primary":
			$klasa = "btn btn-primary";
			break;
		case "secondary":
			$klasa = "btn btn-secondary";
			break;
		case "success":
			$klasa = "btn btn-success";
			break;
		case "danger":
			$klasa = "btn btn-danger";
			break;
		case "warning":
			$klasa = "btn btn-warning";
			break;
		case "info":
			$klasa = "btn btn-info";
			break;
		case "light":
			$klasa = "btn btn-light";
			break;
		case "dark":
			$klasa = "btn btn-dark";
			break;
		default:
			$klasa = "btn btn-primary";
	}

	?><div class="container" style="margin-top:10px;margin-bottom:10px;">
		<div class="row">
			<div class="col-lg-12">
				<button type="submit" name="" class="<?php echo $klasa; ?> btn-block" style="width:100%;"><?php echo $text; ?></button>
			</div>
		</div>
	</div><?php
}


?>