CREATE USER 'usr_php_praktyczny_projekt'@'localhost' IDENTIFIED BY 'pass_usr_php_praktyczny_projekt';
GRANT ALL PRIVILEGES ON php_praktyczny_projekt.* TO 'usr_php_praktyczny_projekt'@'localhost';
