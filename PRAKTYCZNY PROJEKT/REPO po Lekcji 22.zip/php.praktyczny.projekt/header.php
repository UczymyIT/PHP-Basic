<!-- nagłówek -->
<div class="header-container">
<div class="container">
	<div class="row">
		<div class="col-lg-2">
			<img src="images/logo.png">
		</div>
		<div class="col-lg-2">
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
				<input type="hidden" name="button_pressed" value="str2"> 
				<input type="submit" class="btn btn-outline-light my-2 my-sm-0 nav-item" value="Strona2">
			</form>
		</div>
		<div class="col-lg-2">
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
				<input type="hidden" name="button_pressed" value="str3"> 
				<input type="submit" class="btn btn-outline-light my-2 my-sm-0 nav-item" value="Strona3">
			</form>
		</div>
		<div class="col-lg-2">
		</div>
		<div class="col-lg-2">
		</div>
		<div class="col-lg-2">
			<?php
			if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"]==true){ 
			?>
				<form action="logout.php" method="post">
					<button type="submit" class="btn btn-outline-light my-2 my-sm-0 nav-item">Wyloguj się</button>
				</form>
			<?php
			} else {
			?>
				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
					<input type="hidden" name="button_pressed" value="btn_login"> 
					<button type="submit" name="login" class="btn btn-outline-light my-2 my-sm-0 nav-item">Zaloguj się</button>
				</form>
			<?php
			}
			?>
			
		</div>
	</div>
</div>
</div>
