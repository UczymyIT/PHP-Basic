<?php
	// Zestawienie połączenia z bazą danych
	$servername = "localhost";
	$username = "usr_php_praktyczny_projekt";
	$password = "pass_usr_php_praktyczny_projekt";
	$dbname = "php_praktyczny_projekt";

	$conn = new mysqli($servername, $username, $password, $dbname);
	
	// Sprawdzenie połączenia
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
?>
