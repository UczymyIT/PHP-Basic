<?php
// Rozpoczęcie sesji
session_start();

// Usunięcie wszystkich zmiennych sesyjnych
session_unset();

// Zakończenie sesji
session_destroy();

// Przekierowanie użytkownika na stronę logowania lub inną stronę
header("Location: index.php");
exit();
?>
