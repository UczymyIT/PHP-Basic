<div class="container" >
 <div class="row">
  <div class="col-lg-3"style="background:red;">
	logo cz.1
  </div>
  <div class="col-lg-3"style="background:blue;">
	cz.2
  </div>
  <div class="col-lg-6"style="background:yellow;">
	cz.3
  </div>
 </div>
</div>