<!-- PHP Strings Functions Ex.5 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Moja Strona</title>
</head>
<body>
<?php
echo str_replace("world" , "Dolly" , "Hello world!");
?>
</body>
</html>
