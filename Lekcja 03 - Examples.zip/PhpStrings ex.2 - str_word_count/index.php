<!-- PHP Strings Functions Ex.2 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Moja Strona</title>
</head>
<body>
<?php
echo str_word_count("Hello world!");
?>
</body>
</html>
