<!-- Ex. 2.4 Variable Float -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Moja Prosta Strona</title>
</head>
<body>

<?php
$x = 10.365;
echo $x;
echo "<br>";
var_dump($x);
?>

</body>
</html>
