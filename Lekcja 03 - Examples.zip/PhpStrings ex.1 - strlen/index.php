<!-- PHP Strings Functions Ex.1 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Moja Strona</title>
</head>
<body>
<?php
echo strlen("Hello world!");
?>
</body>
</html>
