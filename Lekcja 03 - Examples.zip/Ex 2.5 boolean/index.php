<!-- Ex. 2.5 Variable Boolean -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Moja Strona</title>
</head>
<body>

<?php
$x = true;
$y = false;
echo "x = ".$x;
echo "<br>";
echo var_dump($x);
?>

</body>
</html>
