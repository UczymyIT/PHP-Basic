<!-- Ex. 2.6 Variable Array -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Moja Strona</title>
</head>
<body>

<?php
$cars = array("Volvo","BMW","Toyota");
var_dump($cars);
?>

</body>
</html>
