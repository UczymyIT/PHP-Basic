<!-- Ex. 2.3 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Moja Prosta Strona</title>
</head>
<body>

<?php
$x = 5985;
echo "echo x : ".$x;
echo "<br>var_dump : ";
echo var_dump($x);
?>

</body>
</html>
