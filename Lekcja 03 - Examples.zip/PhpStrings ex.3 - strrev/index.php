<!-- PHP Strings Functions Ex.3 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Moja Strona</title>
</head>
<body>
<?php
echo strrev("Hello world!"); 
?>
</body>
</html>
